// Variables mutables - permitidas pero evitar si es posible

var contador: Int = 0
var activo: Boolean = true
var temperatura: Double = 36.5

var mensaje = "Hola"
var intentos = 3

fun main() {
    contador = 1
    contador = 2
    mensaje = "Adios"
    
    println("Contador: \$contador")
    println("Mensaje: \$mensaje")
}